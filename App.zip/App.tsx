/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { useEffect, useState } from 'react';
import type { PropsWithChildren } from 'react';
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  TextInput,
  Button,
  FlatList,
  NativeModules, AppState,
  Platform,
  PermissionsAndroid
} from 'react-native';

import {
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import NetInfo from '@react-native-community/netinfo';
import axios from 'axios';
import messaging from '@react-native-firebase/messaging';
import Geolocation from 'react-native-geolocation-service';
import ReactNativeForegroundService from "@supersami/rn-foreground-service";

import HeadlessTask from './HeadlessTask';
import VoiceRecorder from './src/components/VoiceRecorder';
import { BACKEND_URL } from './src/utils/constants';
import { loadStorage, saveStorage } from './src/utils/storage';
import RecordingList from './src/components/RecordingList';

function App(): React.JSX.Element {
  const isDarkMode = useColorScheme() === 'dark';
  const [isConnected, setConnected] = useState(false);
  const [messageReceiveCount, setMessageReceiveCount] = useState(0);
  const [location, setLocation] = useState<any>(null);

  const hasLocationPermission = async () => {
    if (Platform.OS === 'ios') {
      return true;
    }

    const granted1 = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: 'Location Access Required',
        message: 'This app needs to access your location',
        buttonPositive: 'OK',
      },
    );

    const granted2 = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_BACKGROUND_LOCATION,
      {
        title: 'Background Location Permission',
        message:
          'We need access to your location ' +
          'so you can get live quality updates.',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'Cancel',
        buttonPositive: 'OK',
      },
    );

    return granted1 === PermissionsAndroid.RESULTS.GRANTED && granted2 === PermissionsAndroid.RESULTS.GRANTED;
  };

  const getLocation = async () => {
    // const hasPermission = await hasLocationPermission();
    // if (!hasPermission) {
    //   return;
    // }

    Geolocation.getCurrentPosition(
      (position) => {
        const latitude = position?.coords?.latitude;
        const longitude = position?.coords?.longitude;

        loadStorage().then((token) => {
          const dataPayload = {
            "latitude": latitude,
            "longitude": longitude,
            "token": token?.token || ""
          };

          console.log(dataPayload, 'dataPayload')

          axios.post(BACKEND_URL + '/save-location', dataPayload)
            .then(response => {
              // console.log("response.data: ", response.data);
            })
            .catch(error => {
              console.error("Error sending data: ", error);
            });
        }, (err) => {
          console.error(err, 'token error'); // Error!
        });
      },
      (error) => {
        console.log(`Code ${error.code}`, error.message)
        // Alert.alert(`Code ${error.code}`, error.message);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  };

  const backgroundStyle = {
    backgroundColor: isDarkMode ? Colors.darker : Colors.lighter,
  };

  const showAlert = () => {
    Alert.alert(
      "No Internet! ❌",
      "Sorry, we need an Internet connection for App to run correctly.",
      [{ text: "Okay" }]
    );
  };

  const recordingStorage = async (message: any) => {
    const list: any = await loadStorage('recordingList');

    // message.uuid = uuid.v4();

    if (Array.isArray(list)) {
      saveStorage([message, ...list], 'recordingList');
    } else {
      saveStorage([message], 'recordingList');
    }
  }

  // fetch token
  const requestUserPermission = async () => {
    try {
      await messaging().requestPermission();
      const token = await messaging().getToken();

      const dataPayload = {
        "token": token
      };

      axios.post(BACKEND_URL + '/device-token', dataPayload)
        .then(response => {
          // console.log("response.data token: ", response.data);
          saveStorage({ "token": token });
        })
        .catch(error => {
          console.error("Error sending data: ", error);
        });
    } catch (error: any) {
      console.log('Permission or Token retrieval error:', error.message);
    }
  };

  // not in use
  const requestPermissions = async () => {
    if (Platform.OS === 'android') {
      try {
        const permissions = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.READ_PHONE_STATE,
        ]);
        console.log('Permissions are:', permissions);
      } catch (err) {
        console.log(err);
      }
    }
  };

  // check internet
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state: any) => {
      setConnected(state.isConnected);
      if (!state.isConnected) {
        showAlert();
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // handleForegroundNotification
  useEffect(() => {
    const handleForegroundNotification = messaging().onMessage((message: any) => {
      console.log('Foreground notification:');
      HeadlessTask(message);

      recordingStorage(message);

      setMessageReceiveCount(pre => ++pre);
    });

    return handleForegroundNotification;
  }, []);

  // handleBackgroundNotification
  useEffect(() => {
    const handleBackgroundNotification = messaging().setBackgroundMessageHandler((message) => {
      console.log('Background notification:');

      HeadlessTask(message);

      recordingStorage(message);

      setMessageReceiveCount(pre => ++pre);
      // Customize the handling of the notification based on your app's requirements
      return Promise.resolve();
    });

    return handleBackgroundNotification;
  }, []);

  // permission for POST_NOTIFICATIONS
  useEffect(() => {
    if (Platform.OS === "android") {
      // Android - Requesting permissions
      PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS
      )
        .then((response) => {
          if (response === PermissionsAndroid.RESULTS.GRANTED) {
            requestUserPermission();
          } else if (response === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
            requestUserPermission();
          } else if (response === PermissionsAndroid.RESULTS.DENIED) {
            console.log("permission android", response);
          }
        })
        .catch((error) => {
          console.log("PermissionsAndroid", error);
        });
    } else if (Platform.OS === "ios") {
      // iOS - Requesting permissions
      requestUserPermission();
    }
  }, [])

  // not in use
  // permission for READ_PHONE_STATE
  useEffect(() => {
    // requestPermissions();
  }, [])

  useEffect(() => {
    // hasLocationPermission().then((hasPermission) => {
    //   if (!hasPermission) {
    //     Alert.alert(`We can not access your location. Position will not work properly`);
    //   }
    // });
    // getLocation();
    // const watchId = Geolocation.watchPosition(
    //   (position) => {
    //     setLocation(position);
    //     // console.log(position, 'position');
    //   },
    //   (error) => {
    //     Alert.alert(`Code ${error.code}`, error.message);
    //   },
    //   { enableHighAccuracy: true, distanceFilter: 0, interval: 5000, fastestInterval: 5000 }
    // );

    // return () => {
    //   Geolocation.clearWatch(watchId);
    // };
  }, []);

  useEffect(() => {
    ReactNativeForegroundService.add_task(() => getLocation(), {
      delay: 5000,
      onLoop: true,
      taskId: 'taskid',
      onError: e => console.log(`Error logging:`, e),
      // onSuccess: () => console.log(`Success Task Run`),
    });
  }, []);

  const startTask = () => {
    hasLocationPermission().then((hasPermission) => {
      if (hasPermission) {
        ReactNativeForegroundService.start({
          id: 1244,
          title: 'Live Location Update Running',
          message: 'To stop go to App and click stop the foreground service',
          icon: 'ic_launcher',
          button: true,
          button2: true,
          buttonText: 'Open App',
          // button2Text: 'Anther Button',
          setOnlyAlertOnce: "true",
          buttonOnPress: 'cray',
          color: '#000000',
          progress: {
            max: 100,
            curr: 50,
          },
        });
      } else {
        Alert.alert(`We can not access your location. Position will not work properly`);
      }
    });
  };

  const stopTask = () => {
    ReactNativeForegroundService.stopAll();
  };

  if (isConnected === false) {
    return (
      <View style={styles.centered}>
        <Text style={styles.title}>
          Please turn on the Internet to use App.
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={backgroundStyle}>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={backgroundStyle.backgroundColor}
      />

      <View style={backgroundStyle}>
        <RecordingList messageReceiveCount={messageReceiveCount} />
      </View>
      <View>
        <Button onPress={startTask} title="Start The foreground Service" />
        <Button onPress={stopTask} color="#dc3545" title="Stop The foreground Service" />
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
  centered: {
    alignItems: "center",
    flex: 1,
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
});

export default App;